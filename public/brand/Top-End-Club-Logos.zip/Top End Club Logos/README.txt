The Top End Club brand kit
topendclub.org/branding

Folders
  Full Color  The complete logos, with the gold frame and shading (PNG)
  SVG         Flat logos, vector, any size
  PNG         Flat logos, high resolution

Colors
  Charlotte Red   #891511  (main accent)
  Concord Gold    #DA872D  (use rarely)
  Red gradient    #B42E25 > #891511 > #530907  (run it top to bottom)
  Gold gradient   #FFFFE6 > #DA882D > #CB7124 > #BC8654

Type
  Headings: Charlotte Italic
  Everything else: Avian Pro

Use the white-type and white logos on dark backgrounds only.
Do not stretch, recolor or add effects to the logos.
